package com.bankSim.TransactionSim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionSimApplicationTests {

	@Test
	void contextLoads() {
	}

}
