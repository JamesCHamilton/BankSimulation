package com.bankSim.TransactionSim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransactionSimApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransactionSimApplication.class, args);
	}

}
